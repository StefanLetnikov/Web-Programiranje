package mk.ukim.finki.wp.exam.example.repository;

public class CategoryRepository {
}
