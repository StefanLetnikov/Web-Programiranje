package mk.ukim.finki.wp.exam.example.service.impl;

public class ProductServiceImpl {
}
